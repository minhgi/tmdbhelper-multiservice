from tmdbhelper.lib.files.database import DataBase


class MDbListSyncDataBase(DataBase):

    _migrated = set()  # db files already migrated by this interpreter: the ALTERs need running once, not per instance

    def migrate_columns(self):
        """Add any columns missing from the on-disk table (schema migration).

        CREATE TABLE IF NOT EXISTS does not alter existing tables, so new columns
        added in later versions must be applied via ALTER TABLE ADD COLUMN.
        SQLite < 3.37 has no ADD COLUMN IF NOT EXISTS — duplicate-column errors
        are caught and ignored.  Uses execute_sql (the same commit path as all
        other DB writes) rather than the connection object from
        create_database_execute, which is not reliably committed.
        """
        if self._db_file in self._migrated:
            return
        self._migrated.add(self._db_file)
        # Only add the columns the table does not have yet. Every new Python invocation starts with an empty _migrated set, so
        # the old try/ALTER/ignore ran ~13 doomed ALTERs per database per call and the database layer logged each one as
        # "duplicate column name" (7.0.88). If the column list cannot be read, fall back to the old try/ALTER/ignore.
        result = self.execute_sql('PRAGMA table_info(simplecache)', ())
        rows = result.fetchall() if result else None
        present = {row[1] for row in rows} if rows else set()
        for col_name, col_def in self.simplecache_columns.items():
            if col_name in present:
                continue
            try:
                self.execute_sql(
                    f'ALTER TABLE simplecache ADD COLUMN {col_name} {col_def["data"]}', ())
            except Exception:
                pass  # column already present

    simplecache_columns = {
        'item_type': {
            'data': 'TEXT',
            'sync': None
        },
        'tmdb_type': {
            'data': 'TEXT',
            'sync': None
        },
        'tmdb_id': {
            'data': 'INTEGER',
            'sync': None
        },
        'season_number': {
            'data': 'INTEGER',
            'sync': None
        },
        'episode_number': {
            'data': 'INTEGER',
            'sync': None
        },
        'plays': {
            'data': 'INTEGER DEFAULT 0',
            'sync': ('tmdbhelper.lib.api.mdblist.sync.datatype', 'MDbListSyncWatched', )
        },
        'last_watched_at': {
            'data': 'TEXT',
            'sync': ('tmdbhelper.lib.api.mdblist.sync.datatype', 'MDbListSyncWatched', )
        },
        'watched_episodes': {
            'data': 'INTEGER',
            'sync': ('tmdbhelper.lib.api.mdblist.sync.datatype', 'MDbListSyncWatched', )
        },
        'paused_progress': {
            'data': 'INTEGER',
            'sync': ('tmdbhelper.lib.api.mdblist.sync.datatype', 'MDbListSyncPaused', )
        },
        'paused_at': {
            'data': 'TEXT',
            'sync': ('tmdbhelper.lib.api.mdblist.sync.datatype', 'MDbListSyncPaused', )
        },
        'paused_id': {
            'data': 'INTEGER',
            'sync': ('tmdbhelper.lib.api.mdblist.sync.datatype', 'MDbListSyncPaused', )
        },
        'watchlist_listed_at': {
            'data': 'TEXT',
            'sync': ('tmdbhelper.lib.api.mdblist.sync.datatype', 'MDbListSyncWatchlist', )
        },
        'collection_collected_at': {
            'data': 'TEXT',
            'sync': ('tmdbhelper.lib.api.mdblist.sync.datatype', 'MDbListSyncCollection', )
        },
        'rating': {
            'data': 'INTEGER',
            'sync': None
        },
        'rated_at': {
            'data': 'TEXT',
            'sync': None
        },
    }
