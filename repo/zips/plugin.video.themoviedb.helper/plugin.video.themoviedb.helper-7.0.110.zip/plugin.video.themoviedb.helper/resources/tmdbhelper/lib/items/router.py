from tmdbhelper.lib.addon.logger import kodi_log
from jurialmunkey.parser import parse_paramstring, reconfigure_legacy_params


class Router():
    def __init__(self, handle, paramstring):
        # plugin:// params configuration
        self.handle = handle  # plugin:// handle
        self.paramstring, *secondary_params = paramstring.split('&&')  # plugin://plugin.video.themoviedb.helper?paramstring
        self.params = reconfigure_legacy_params(**parse_paramstring(self.paramstring))  # paramstring dictionary
        if self.params.get('season'):
            from tmdbhelper.lib.api.tmdb.season_layout import remap_params
            remap_params(self.params)  # layout season/episode numbers from a skin -> real TMDb numbers
        if not secondary_params:
            return
        from urllib.parse import unquote_plus
        self.params['paths'] = [unquote_plus(i) for i in secondary_params]

    def play_external(self):
        from tmdbhelper.lib.player.players import Players
        from tmdbhelper.lib.api.tmdb.api import TMDb
        kodi_log(['lib.container.router - Attempting to play item\n', self.params], 1)
        if not self.params.get('tmdb_id'):
            self.params['tmdb_id'] = TMDb().get_tmdb_id(**self.params)
        Players(**self.params).play(handle=self.handle if self.handle != -1 else None)

    def context_related(self):
        from tmdbhelper.lib.script.method.context_menu import related_lists
        from tmdbhelper.lib.api.tmdb.api import TMDb
        if not self.params.get('tmdb_id'):
            self.params['tmdb_id'] = TMDb().get_tmdb_id(**self.params)
        self.params['container_update'] = True
        related_lists(include_play=True, **self.params)

    def run_action(self):
        from tmdbhelper.lib.script.sync.dropped import ACTIONS
        ACTIONS[self.params['info']]()

    def get_directory(self, items_only=False, build_items=True):
        from tmdbhelper.lib.items.routes import get_container
        container = get_container(self.params.get('info'))(self.handle, self.paramstring, **self.params)
        if not items_only and build_items and container.missing_tmdb_type():
            # A skin path built from a row that is no movie or show (e.g. "Next page") has no type: finish it empty, not with a traceback
            kodi_log(['lib.container.router - Skipped, the path has no type\n', self.paramstring], 1)
            return container.finish_container()
        container.get_tmdb_id()  # TODO: Only get this as necessary
        return container.get_directory(items_only, build_items)

    def run(self):
        if self.params.get('info') == 'play':
            return self.play_external()
        if self.params.get('info') == 'related':
            return self.context_related()
        if self.params.get('info') in ('trakt_dropped_restore', 'trakt_watchlist_drop', 'mdblist_dropped_restore'):
            return self.run_action()
        self.get_directory()
