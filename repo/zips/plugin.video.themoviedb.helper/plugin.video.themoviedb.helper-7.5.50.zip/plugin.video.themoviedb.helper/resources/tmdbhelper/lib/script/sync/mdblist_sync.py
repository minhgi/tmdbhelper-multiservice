from tmdbhelper.lib.files.ftools import cached_property
from tmdbhelper.lib.addon.plugin import get_localized, executebuiltin
from tmdbhelper.lib.addon.dialog import BusyDialog
from tmdbhelper.lib.addon.logger import kodi_log
from xbmcgui import Dialog


class ItemMDbListSyncBase:
    """Base class for MDBList write sync context menu items.

    Auth:   API key appended to URL via get_request_url (always sent).
            Bearer OAuth token in Authorization header (sent when available).
            Either credential is sufficient — consistent with Phase B behavior.
    Writes: All use method='json' (POST with JSON body).
    Remove: POST to '<path>/remove' suffix — never HTTP DELETE.
    Payload format confirmed from Umbrella + POV reference addons:
        Movie:   {'movies': [{'tmdb': id}]}
        Show:    {'shows':  [{'tmdb': id}]}
        Season:  {'shows':  [{'tmdb': id, 'seasons': [{'number': sn}]}]}
        Episode: {'shows':  [{'tmdb': id, 'seasons': [{'number': sn, 'episodes': [{'number': ep}]}]}]}
    """

    allow_seasons = False
    allow_episodes = False
    preconfigured = False

    def __init__(self, tmdb_type, tmdb_id, season=None, episode=None):
        self.tmdb_type = tmdb_type
        self.tmdb_id = tmdb_id
        self.season = season
        self.episode = episode

    # --- API + sync data ---

    @cached_property
    def mdblist_api(self):
        from tmdbhelper.lib.api.mdblist.api import MDbList
        return MDbList()

    @cached_property
    def mdblist_syncdata(self):
        return self.mdblist_api.mdblist_syncdata

    # --- Authorization gate ---

    @cached_property
    def is_authorized(self):
        """Allow OAuth token OR personal API key (writes work with either)."""
        return bool(self.mdblist_api.user_token.value or self.mdblist_api.api_key)

    # --- Item type helpers ---

    @cached_property
    def mdb_type(self):
        if self.tmdb_type == 'movie':
            return 'movie'
        if self.tmdb_type != 'tv':
            return None
        if self.season is None:
            return 'show'
        if self.episode is None:
            return 'season'
        return 'episode'

    @cached_property
    def mdb_base_type(self):
        return 'movie' if self.tmdb_type == 'movie' else 'show'

    @cached_property
    def is_allowed_type(self):
        if self.season is None:
            return True
        if self.episode is None:
            return self.allow_seasons
        return self.allow_episodes

    # --- Payload ---

    def build_payload(self, extra_fields=None):
        extra_fields = extra_fields or {}
        tmdb_id = int(self.tmdb_id)
        if self.mdb_type == 'movie':
            item = {'tmdb': tmdb_id}
            item.update(extra_fields)
            return {'movies': [item]}
        if self.mdb_type == 'show':
            item = {'tmdb': tmdb_id}
            item.update(extra_fields)
            return {'shows': [item]}
        if self.mdb_type == 'season':
            return {'shows': [{'tmdb': tmdb_id, 'seasons': [{'number': int(self.season)}]}]}
        if self.mdb_type == 'episode':
            return {'shows': [{'tmdb': tmdb_id, 'seasons': [{'number': int(self.season), 'episodes': [{'number': int(self.episode)}]}]}]}
        return {}

    # --- API call ---

    def call_api(self, *path_parts, extra_fields=None):
        """POST to MDBList API. Sends API key (URL param) + Bearer token (header if available)."""
        url = self.mdblist_api.get_request_url(*path_parts)
        payload = self.build_payload(extra_fields)
        with BusyDialog():
            return self.mdblist_api.get_api_request(
                url,
                postdata=payload,
                method='json',
                headers=self.mdblist_api.auth_headers)

    # --- Sync state for add/remove toggle ---

    def get_sync_value(self, key):
        """Read current toggle state directly from DB — no sync triggered.

        Root-cause: get_value() calls sync() before reading, which invokes
        MDbListSyncWatchlist/Collection.sync() → clear_columns() → NULLs ALL
        toggle data for that item_type on every context menu open.  That wipes
        any value update_toggle_in_db just wrote.  Reading from cache directly
        bypasses the clear-and-refetch cycle entirely.
        """
        try:
            db_type = 'movie' if self.tmdb_type == 'movie' else 'tv'
            season = self.season if self.mdb_type in ('season', 'episode') else None
            episode = self.episode if self.mdb_type == 'episode' else None
            item_id = self.mdblist_syncdata.get_name(db_type, self.tmdb_id, season, episode)
            values = self.mdblist_syncdata.cache.get_values(item_id=item_id, keys=(key,))
            return values[0] if values else None
        except Exception:
            return None

    # --- Cached sync response ---

    @cached_property
    def sync_response(self):
        return self.get_sync_response()

    def get_sync_response(self):
        raise NotImplementedError

    @cached_property
    def is_successful_sync(self):
        """get_api_request returns None for 4xx/5xx/connection errors; response object for 2xx."""
        return self.sync_response is not None

    # --- Post-sync actions ---

    def reset_lastactivities(self):
        if self.is_successful_sync:
            self.mdblist_syncdata.reset_lastactivities()

    def update_toggle_in_db(self, key, value):
        """Directly write a toggle column into the local sync DB after a successful write.

        Root-cause analysis:
          • MDbListDataType.sync(forced=False) calls is_expired(), which compares the
            stored DB activity timestamp against last_activities['watchlisted_at'|...].
            Because store_last_activity() stores last_activities['all'] (the maximum of
            all timestamps) as the reference, watchlisted_at <= all always, so
            is_expired() returns False after the first sync.  No re-sync ever runs.
          • force_refresh_sync(forced=True) bypasses is_expired but the try/except
            silently swallows mutex/timerlock errors, so nothing appears in the log.

        Direct SQL fix:
          • add to list  → INSERT OR IGNORE row, then set_many_values (update_if_null) to
                           stamp the column with the current UTC timestamp.
          • remove from list → execute UPDATE … SET col=NULL WHERE id=? directly.
          In both cases get_values() reads the DB AFTER calling sync() — whether or not
          sync actually ran, the DB value we wrote here is what comes back.
        """
        if not self.is_successful_sync:
            return
        try:
            db_type = self.tmdb_type          # 'movie' or 'tv'
            tmdb_id = int(self.tmdb_id)
            item_id = f'{db_type}.{tmdb_id}'
            cache = self.mdblist_syncdata.cache

            if value:
                from datetime import datetime, timezone
                ts = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000Z')
                item_type_str = self.mdb_base_type  # 'movie' or 'show'
                # table_keys mirrors MDbListSyncItem.table_keys for this method
                keys = (key, 'item_type', 'tmdb_type', 'tmdb_id', 'season_number', 'episode_number')
                data = {item_id: [ts, item_type_str, db_type, tmdb_id, None, None]}
                cache.set_many_values(keys=keys, data=data)
            else:
                # set_many_values only writes to NULL columns; use raw SQL to clear
                cache.execute_sql(
                    cache.statement_delete_keys('simplecache', (key,), conditions='id=?'),
                    (item_id,))
        except Exception:
            pass

    def update_watched_in_db(self, value, force=False):
        """Directly write watched state (plays + last_watched_at) to local sync DB.

        Cannot use update_toggle_in_db / set_many_values for 'plays' because the
        column is INTEGER DEFAULT 0 (not NULL).  ifnull(1, 0) = 0 — the UPDATE
        is a no-op.  Plain UPDATE with literal values overwrites unconditionally.

        Scoped to movie and episode only (direct plays column exists at those
        levels).  Show/season watched_episodes aggregation is left to the next
        periodic sync — attempting to reconstruct counts here would be fragile.
        """
        if not force and not self.is_successful_sync:
            return
        if self.mdb_type not in ('movie', 'episode', 'show'):
            return
        try:
            db_type = self.tmdb_type  # 'movie' or 'tv'
            tmdb_id = int(self.tmdb_id)
            season = int(self.season) if self.mdb_type == 'episode' else None
            episode = int(self.episode) if self.mdb_type == 'episode' else None
            item_id = self.mdblist_syncdata.get_name(db_type, tmdb_id, season, episode)
            cache = self.mdblist_syncdata.cache
            from tmdbhelper.lib.script.sync.watched_totals import recount_totals
            if value:
                from datetime import datetime, timezone
                ts = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000Z')
                cache.execute_sql(
                    cache.statement_insert_or_ignore('simplecache', ('id',)),
                    (item_id,))
                if self.mdb_type == 'show':
                    # watched_episodes=9999 sentinel makes badge appear immediately.
                    # get_playcount() returns min(9999, air_count) = air_count.
                    # Next periodic sync overwrites with the real count.
                    cache.execute_sql(
                        'UPDATE simplecache SET last_watched_at=?, watched_episodes=?,'
                        ' item_type=?, tmdb_type=?, tmdb_id=?,'
                        ' season_number=?, episode_number=? WHERE id=?',
                        (ts, 9999, 'show', db_type, tmdb_id, None, None, item_id))
                else:
                    item_type_str = 'movie' if self.mdb_type == 'movie' else 'episode'
                    # Plain UPDATE — ifnull(1, 0) = 0 so set_many_values cannot set plays=1
                    cache.execute_sql(
                        'UPDATE simplecache SET plays=?, last_watched_at=?,'
                        ' item_type=?, tmdb_type=?, tmdb_id=?,'
                        ' season_number=?, episode_number=? WHERE id=?',
                        (1, ts, item_type_str, db_type, tmdb_id, season, episode, item_id))
                    if self.mdb_type == 'episode':
                        recount_totals(cache, tmdb_id, season, ts)
            else:
                if self.mdb_type == 'show':
                    cache.execute_sql(
                        'UPDATE simplecache SET last_watched_at=NULL, watched_episodes=0 WHERE id=?',
                        (item_id,))
                else:
                    cache.execute_sql(
                        'UPDATE simplecache SET plays=0, last_watched_at=NULL WHERE id=?',
                        (item_id,))
                    if self.mdb_type == 'episode':
                        recount_totals(cache, tmdb_id, season)
        except Exception:
            pass

    def resync_after_season_mark(self):
        if self.mdb_type == 'season' and self.is_successful_sync:
            with BusyDialog():
                resync_season_watched(self.mdblist_syncdata)

    def display_dialog(self):
        if self.is_successful_sync:
            msg = get_localized(32297)
        else:
            msg = get_localized(32296)
        Dialog().ok(self.name, msg.format(self.name, self.tmdb_type, 'TMDb', self.tmdb_id))

    def refresh_containers(self, force=False):
        if not force and not self.is_successful_sync:
            return
        from tmdbhelper.lib.script.method.kodi_utils import reload_widgets
        executebuiltin('Container.Refresh')
        reload_widgets()

    def sync(self):
        self.reset_lastactivities()
        self.display_dialog()
        self.refresh_containers()

    # --- Menu display gate ---

    def get_self(self):
        """Return self to include in menu; None to exclude."""
        if not self.is_authorized:
            return
        if not self.is_allowed_type:
            return
        return self

    @cached_property
    def name(self):
        return self.get_name()

    def get_name(self):
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Concrete sync item classes
# ---------------------------------------------------------------------------

def resync_season_watched(syncdata):
    """Read MDBList's watched data again after a SEASON was set watched / unwatched (here or by a copy from another menu). A season mark writes
    nothing to the saved rows (its episodes are not known here), so without this the season menu would keep the old option until the next
    periodic sync. The same forced read the Unwatched seasons / episodes lists make. Movie and episode marks write their row and are not
    re-read. A read that fails keeps the saved rows."""
    try:
        syncdata.reset_lastactivities()  # the stamps stored with the read must be the ones after this mark
        syncdata.sync('show', ('plays', 'watched_episodes'), forced=True)
    except Exception as exc:
        kodi_log(f'MDBList: watched data not read again after a season mark - {type(exc).__name__}', 1)


class ItemMDbListWatched(ItemMDbListSyncBase):
    """Mark movie / show / season / episode as watched.

    Endpoint confirmed (Umbrella + POV): POST /sync/watched
    """
    allow_seasons = True
    allow_episodes = True
    preconfigured = True

    def get_self(self):
        # super() handles is_authorized + is_allowed_type
        if not super().get_self():
            return None
        # Toggle: hide "Mark as watched" when already watched.
        # Shows use last_watched_at (plays is always 0 for show-level rows);
        # movies and episodes use plays.
        if self.mdb_type == 'show':
            if self.get_sync_value('last_watched_at'):
                return None
        elif self.get_sync_value('plays'):
            return None
        return self

    def get_name(self):
        return get_localized(16103)  # "Set as watched"

    def get_sync_response(self):
        return self.call_api('sync', 'watched')

    def clear_resume_point(self):
        """An item set as watched must not keep its resume percentage (GitHub issue #13 item 4); see the
        module-level clear_resume_point(). Only after the watched call succeeded."""
        if self.is_successful_sync:
            clear_resume_point(self.tmdb_type, self.tmdb_id, self.season, self.episode)

    def sync(self):
        # reset_lastactivities() intentionally omitted: prevents MDBList sync from
        # running on Container.Refresh and wiping the plays value we just wrote.
        _ = self.sync_response  # trigger API call first; local write and refresh proceed regardless
        self.update_watched_in_db(True, force=True)
        self.resync_after_season_mark()
        self.clear_resume_point()
        self.display_dialog()
        self.refresh_containers(force=True)
        if self.is_successful_sync:
            from tmdbhelper.lib.script.sync.cross_sync import mirror_watched_to_trakt, mirror_watched_to_simkl, mirror_watched_to_wetrakr
            mirror_watched_to_trakt(self.tmdb_type, self.tmdb_id, self.season, self.episode, remove=False)
            mirror_watched_to_simkl(self.tmdb_type, self.tmdb_id, self.season, self.episode, remove=False)
            mirror_watched_to_wetrakr(self.tmdb_type, self.tmdb_id, self.season, self.episode, remove=False)


class ItemMDbListUnwatched(ItemMDbListSyncBase):
    """Remove movie / show / season / episode from watched history.

    Endpoint confirmed (Umbrella + POV): POST /sync/watched/remove
    Also attempts best-effort scrobble bookmark cleanup so item leaves
    In-Progress widgets (POST /scrobble/clear with paused_id from sync DB).
    """
    allow_seasons = True
    allow_episodes = True
    preconfigured = True

    def get_self(self):
        # super() handles is_authorized + is_allowed_type
        if not super().get_self():
            return None
        # Toggle: hide "Mark as unwatched" when not watched.
        # Shows use last_watched_at; movies and episodes use plays. A season row has neither, only its watched-episode count.
        if self.mdb_type == 'show':
            if not self.get_sync_value('last_watched_at'):
                return None
        elif self.mdb_type == 'season':
            if not self.get_sync_value('watched_episodes'):
                return None
        elif not self.get_sync_value('plays'):
            return None
        return self

    def get_name(self):
        return get_localized(16104)  # "Set as unwatched"

    def get_sync_response(self):
        return self.call_api('sync', 'watched', 'remove')

    def _clear_playback_progress(self):
        """Best-effort: clear MDBList scrobble bookmark so item leaves In-Progress.
        Only applies to movie/episode; show/season-level has no single paused_id.
        Deferred gap: If MDBList clears playback server-side on watched/remove, this
        is redundant — but harmless. If not, this keeps local DB consistent.
        """
        if not self.is_successful_sync:
            return
        if self.mdb_type not in ('movie', 'episode'):
            return
        try:
            db_type = 'movie' if self.mdb_type == 'movie' else 'tv'
            paused_id = self.mdblist_syncdata.get_value(
                db_type, self.tmdb_id,
                season=self.season if self.mdb_type == 'episode' else None,
                episode=self.episode if self.mdb_type == 'episode' else None,
                key='paused_id')
            if not paused_id:
                return
            url = self.mdblist_api.get_request_url('scrobble', 'clear')
            with BusyDialog():
                self.mdblist_api.get_api_request(
                    url,
                    postdata={'id': paused_id},
                    method='json',
                    headers=self.mdblist_api.auth_headers)
        except Exception:
            pass

    def sync(self):
        self._clear_playback_progress()  # also triggers sync_response (API call + BusyDialog)
        # reset_lastactivities() intentionally omitted: same reasoning as ItemMDbListWatched.
        self.update_watched_in_db(False, force=True)
        self.resync_after_season_mark()
        self.display_dialog()
        self.refresh_containers(force=True)
        if self.is_successful_sync:
            from tmdbhelper.lib.script.sync.cross_sync import mirror_watched_to_trakt, mirror_watched_to_simkl, mirror_watched_to_wetrakr
            mirror_watched_to_trakt(self.tmdb_type, self.tmdb_id, self.season, self.episode, remove=True)
            mirror_watched_to_simkl(self.tmdb_type, self.tmdb_id, self.season, self.episode, remove=True)
            mirror_watched_to_wetrakr(self.tmdb_type, self.tmdb_id, self.season, self.episode, remove=True)


class ItemMDbListWatchlist(ItemMDbListSyncBase):
    """Add / remove movie or show from MDBList watchlist.

    Write endpoints confirmed (Umbrella + POV):
        Add:    POST /watchlist/items/add
        Remove: POST /watchlist/items/remove
    Note: These differ from the read endpoint GET /sync/watchlist used in Phase B.
    Season/episode watchlist not supported by MDBList (show-level only).
    """

    @cached_property
    def remove(self):
        return bool(self.get_sync_value('watchlist_listed_at'))

    def get_name(self):
        return get_localized(32292 if self.remove else 32291)
        # 32291 = "Add to watchlist" | 32292 = "Remove from watchlist"

    def get_sync_response(self):
        if self.remove:
            return self.call_api('watchlist', 'items', 'remove')
        return self.call_api('watchlist', 'items', 'add')

    def sync(self):
        self.reset_lastactivities()
        # not self.remove: True=adding→stamp timestamp, False=removing→set NULL
        self.update_toggle_in_db('watchlist_listed_at', not self.remove)
        self.display_dialog()
        self.refresh_containers()
        if self.is_successful_sync:
            from tmdbhelper.lib.script.sync.cross_sync import mirror_watchlist_to_trakt, mirror_watchlist_to_simkl, mirror_watchlist_to_wetrakr
            mirror_watchlist_to_trakt(self.tmdb_type, self.tmdb_id, self.remove)
            if not self.remove:
                mirror_watchlist_to_simkl(self.tmdb_type, self.tmdb_id)
            mirror_watchlist_to_wetrakr(self.tmdb_type, self.tmdb_id, self.remove)


class ItemMDbListCollection(ItemMDbListSyncBase):
    """Add / remove movie / show from MDBList collection (not offered on seasons or episodes, GitHub issue #13).

    Write endpoints confirmed (POV):
        Add:    POST /sync/collection
        Remove: POST /sync/collection/remove
    """

    @cached_property
    def remove(self):
        return bool(self.get_sync_value('collection_collected_at'))

    def get_name(self):
        return get_localized(32290 if self.remove else 32289)
        # 32289 = "Add to collection" | 32290 = "Remove from collection"

    def get_sync_response(self):
        if self.remove:
            return self.call_api('sync', 'collection', 'remove')
        return self.call_api('sync', 'collection')

    def sync(self):
        self.reset_lastactivities()
        self.update_toggle_in_db('collection_collected_at', not self.remove)
        self.display_dialog()
        self.refresh_containers()
        if self.is_successful_sync:
            from tmdbhelper.lib.script.sync.cross_sync import mirror_collection_to_trakt, mirror_collection_to_wetrakr
            mirror_collection_to_trakt(self.tmdb_type, self.tmdb_id, self.season, self.episode, self.remove)
            mirror_collection_to_wetrakr(self.tmdb_type, self.tmdb_id, self.season, self.episode, self.remove)


class ItemMDbListDrop(ItemMDbListSyncBase):
    """Drop a show on MDBList (one-way; restore from the Dropped Shows list). Show level only.

    POST /sync/dropped {"shows": [{"ids": {"tmdb": N}, "dropped_at": "..."}]} (live-checked 2026-10-14: any known show is accepted, watch
    history is not required, dropped_at is optional; an unknown id comes back as not_found {"shows": 1} plus an errors list) - a count or an
    itemized list are both handled, and that case gets its own message.
    """
    preconfigured = True

    def get_self(self):
        if not super().get_self():
            return None
        if self.mdb_type != 'show':
            return None
        return self

    def get_name(self):
        return get_localized(32577)  # "Drop show"

    def build_payload(self, extra_fields=None):
        from datetime import datetime, timezone
        ts = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
        return {'shows': [{'ids': {'tmdb': int(self.tmdb_id)}, 'dropped_at': ts}]}

    def get_sync_response(self):
        return self.call_api('sync', 'dropped')

    @cached_property
    def reply(self):
        try:
            data = self.sync_response.json()
        except (ValueError, AttributeError):
            return {}
        return data if isinstance(data, dict) else {}

    @cached_property
    def not_found_shows(self):
        from tmdbhelper.lib.script.sync.dropped import count_of
        return count_of((self.reply.get('not_found') or {}).get('shows'))

    @cached_property
    def is_successful_sync(self):
        return self.sync_response is not None and not self.not_found_shows

    def display_dialog(self):
        if self.sync_response is not None and self.not_found_shows:
            Dialog().ok(self.name, get_localized(32579))
            return
        super().display_dialog()

    def sync(self):
        self.display_dialog()
        self.refresh_containers()


class ItemMDbListClearProgress(ItemMDbListSyncBase):
    """Clear the resume point of a movie / episode on MDBList without marking it unwatched.

    Endpoint: POST /scrobble/clear {"id": <playback entry id>}.
    Shown only while a local resume point exists (paused_progress), same gate idea as Trakt's
    progress item. The entry ids are looked up live from GET /sync/playback by TMDb ids rather
    than taken from the local paused_id: the scrobbler writes paused_progress/paused_at on pause
    but the id only arrives with the next playback sync, so a fresh bookmark has no id yet.
    """
    allow_episodes = True
    preconfigured = True

    def get_self(self):
        if not super().get_self():
            return None
        if self.mdb_type not in ('movie', 'episode'):
            return None  # show/season have no single resume point
        if not self.get_sync_value('paused_progress'):
            return None
        return self

    def get_name(self):
        return get_localized(38209)  # "Reset resume position" (Kodi core string, same label as Trakt's item)

    @staticmethod
    def _to_int(value):
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def get_playback_ids(self):
        """Ids of this item's entries in GET /sync/playback, or None when the read failed."""
        url = self.mdblist_api.get_request_url('sync', 'playback')
        response = self.mdblist_api.get_api_request(url, headers=self.mdblist_api.auth_headers)
        if response is None:
            return None
        try:
            entries = response.json()
        except (ValueError, AttributeError):
            return None
        if not isinstance(entries, list):
            return None
        tmdb_id = self._to_int(self.tmdb_id)
        ids = []
        for entry in entries:
            if not isinstance(entry, dict) or entry.get('id') is None:
                continue
            if self.mdb_type == 'movie':
                if entry.get('type') != 'movie':
                    continue
                if self._to_int(((entry.get('movie') or {}).get('ids') or {}).get('tmdb')) != tmdb_id:
                    continue
            else:
                if entry.get('type') != 'episode':
                    continue
                episode = entry.get('episode') or {}
                if self._to_int(((entry.get('show') or {}).get('ids') or {}).get('tmdb')) != tmdb_id:
                    continue
                if self._to_int(episode.get('season')) != self._to_int(self.season):
                    continue
                if self._to_int(episode.get('number')) != self._to_int(self.episode):
                    continue
            ids.append(entry['id'])
        return ids

    def get_sync_response(self):
        """A dict (truthy for is_successful_sync) when every entry was cleared or none was left; None on failure."""
        with BusyDialog():
            ids = self.get_playback_ids()
            if ids is None:
                return None  # could not read the server - leave the local row alone
            url = self.mdblist_api.get_request_url('scrobble', 'clear')
            for playback_id in ids:
                response = self.mdblist_api.get_api_request(
                    url, postdata={'id': playback_id}, method='json',
                    headers=self.mdblist_api.auth_headers)
                if response is None:
                    return None
        return {'cleared': len(ids)}

    def update_progress_in_db(self, force=False):
        if not force and not self.is_successful_sync:
            return
        try:
            db_type = 'movie' if self.mdb_type == 'movie' else 'tv'
            season = int(self.season) if self.mdb_type == 'episode' else None
            episode = int(self.episode) if self.mdb_type == 'episode' else None
            item_id = self.mdblist_syncdata.get_name(db_type, int(self.tmdb_id), season, episode)
            self.mdblist_syncdata.cache.execute_sql(
                'UPDATE simplecache SET paused_progress=0, paused_at=NULL, paused_id=NULL WHERE id=?',
                (item_id,))
        except Exception:
            pass

    def sync(self):
        _ = self.sync_response
        self.update_progress_in_db()
        self.display_dialog()
        self.refresh_containers()


def clear_resume_point(tmdb_type, tmdb_id, season=None, episode=None):
    """Remove the resume point of a movie / episode that was just marked watched (GitHub issue #13 item 4), whether the
    mark was made on MDBList itself (ItemMDbListWatched) or mirrored from another service (cross_sync).

    Kodi draws the percentage from the local paused_progress row, and a watched mark left that row in place, so the
    percentage stayed until Reset resume position was run by hand. MDBList also keeps the playback entry after a watched
    call (live-checked 2026-11-15), so only a server clear stops the next playback sync from bringing the row back.
    Done only for a movie / episode that still has a local resume point: the playback entries are read and cleared on
    the server (same calls as Reset resume position), then the local row is cleared whether or not the server answered.
    Never mirrors anything, so cross_sync may call it (it only instantiates this clear-progress item).
    """
    if tmdb_type not in ('movie', 'tv') or (tmdb_type == 'tv' and (season is None or episode is None)):
        return
    try:
        clear = ItemMDbListClearProgress(tmdb_type, tmdb_id, season, episode)
        if not clear.get_sync_value('paused_progress'):
            return
        _ = clear.sync_response  # best effort; a failed read or clear leaves the server entry for the next sync
        clear.update_progress_in_db(force=True)
    except Exception:
        pass


class ItemMDbListRating(ItemMDbListSyncBase):
    """Rate a movie, show, season, or episode on MDBList.

    Endpoint confirmed from MDBList API docs (apiary.apib):
        Add/change: POST /sync/ratings
        Remove:     POST /sync/ratings/remove   (rating=0)

    Payload nests the rating at the correct hierarchy level:
        Movie:   {"movies": [{"tmdb": id, "rating": X}]}
        Show:    {"shows":  [{"tmdb": id, "rating": X}]}
        Season:  {"shows":  [{"tmdb": id, "seasons": [{"number": sn, "rating": X}]}]}
        Episode: {"shows":  [{"tmdb": id, "seasons": [{"number": sn, "episodes": [{"number": ep, "rating": X}]}]}]}
    """
    allow_seasons = True
    allow_episodes = True

    @cached_property
    def current_rating(self):
        return self.get_sync_value('rating') or 0

    def get_name(self):
        if self.current_rating:
            return f'{get_localized(32489)} ({self.current_rating})'  # "Change Rating (X)"
        return get_localized(32485)  # "Add rating"

    def build_rating_payload(self, rating):
        """Build /sync/ratings payload with rating nested at the correct level.
        rating=0 omits the rating field (used for the remove endpoint).
        """
        tmdb_id = int(self.tmdb_id)
        if self.mdb_type == 'movie':
            item = {'tmdb': tmdb_id}
            if rating:
                item['rating'] = rating
            return {'movies': [item]}
        if self.mdb_type == 'show':
            item = {'tmdb': tmdb_id}
            if rating:
                item['rating'] = rating
            return {'shows': [item]}
        if self.mdb_type == 'season':
            season = {'number': int(self.season)}
            if rating:
                season['rating'] = rating
            return {'shows': [{'tmdb': tmdb_id, 'seasons': [season]}]}
        if self.mdb_type == 'episode':
            episode = {'number': int(self.episode)}
            if rating:
                episode['rating'] = rating
            return {'shows': [{'tmdb': tmdb_id, 'seasons': [
                {'number': int(self.season), 'episodes': [episode]}]}]}
        return {}

    def call_rating_api(self, x):
        payload = self.build_rating_payload(x)
        if not payload:
            return None
        path_parts = ('sync', 'ratings', 'remove') if x == 0 else ('sync', 'ratings')
        url = self.mdblist_api.get_request_url(*path_parts)
        with BusyDialog():
            return self.mdblist_api.get_api_request(
                url, postdata=payload, method='json',
                headers=self.mdblist_api.auth_headers)

    def get_sync_response(self):
        try:
            x = int(Dialog().numeric(0, f'{get_localized(32485)} (0-10)'))
        except ValueError:
            return None  # cancelled — _rating_value intentionally not set
        if x < 0 or x > 10:
            return None
        self._rating_value = x
        from tmdbhelper.lib.script.sync.rating import get_rating_header
        self.name = get_rating_header(x, self.current_rating)  # popup title; read before the new value is stored
        return self.call_rating_api(x)

    def update_rating_in_db(self, force=False):
        """Override to support season/episode item IDs and level-specific item_type."""
        if not force and not self.is_successful_sync:
            return
        rating = getattr(self, '_rating_value', None)
        if rating is None:
            return
        try:
            db_type = self.tmdb_type
            tmdb_id = int(self.tmdb_id)
            season = int(self.season) if self.mdb_type in ('season', 'episode') else None
            episode = int(self.episode) if self.mdb_type == 'episode' else None
            item_id = self.mdblist_syncdata.get_name(db_type, tmdb_id, season, episode)
            item_type_str = self.mdb_type  # 'movie', 'show', 'season', 'episode'
            cache = self.mdblist_syncdata.cache
            if rating:
                from datetime import datetime, timezone
                ts = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.000Z')
                cache.execute_sql(
                    cache.statement_insert_or_ignore('simplecache', ('id',)),
                    (item_id,))
                cache.execute_sql(
                    'UPDATE simplecache SET rating=?, rated_at=?,'
                    ' item_type=?, tmdb_type=?, tmdb_id=?,'
                    ' season_number=?, episode_number=? WHERE id=?',
                    (rating, ts, item_type_str, db_type, tmdb_id, season, episode, item_id))
            else:
                cache.execute_sql(
                    'UPDATE simplecache SET rating=NULL, rated_at=NULL WHERE id=?',
                    (item_id,))
        except Exception:
            pass

    def sync(self):
        _ = self.sync_response  # triggers dialog + API call; sets self._rating_value if valid input
        if not hasattr(self, '_rating_value'):
            return  # user cancelled dialog
        self.update_rating_in_db(force=True)
        self.display_dialog()
        self.refresh_containers(force=True)
        if self.is_successful_sync:
            from tmdbhelper.lib.script.sync.cross_sync import mirror_rating_to_trakt, mirror_rating_to_wetrakr, mirror_rating_to_simkl
            mirror_rating_to_trakt(self.tmdb_type, self.tmdb_id, self.season, self.episode, self._rating_value)
            mirror_rating_to_simkl(self.tmdb_type, self.tmdb_id, self.season, self.episode, self._rating_value)
            mirror_rating_to_wetrakr(self.tmdb_type, self.tmdb_id, self.season, self.episode, self._rating_value)
